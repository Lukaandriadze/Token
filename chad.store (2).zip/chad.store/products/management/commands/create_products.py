from django.core.management.base import BaseCommand
from faker import Faker
import random
from products.models import Product
from products.choices import Currency
class Command(BaseCommand):
    def handle(self,*args, **kwargs):
        faker = Faker()
        products_to_create = []
        currency_data = [Currency.GEL,Currency.USD,Currency.EURO,]
        for _ in range(1000):
            name = faker.name()
            description = faker.text(max_nb_chars=500)
            price = round(random.uniform(1,1000))
            price = round(price,2)
            currency = random.choice(currency_data)
            quantity = faker.random_int(min=1, max=1000)
            product = Product(name=name, description=description, price=price, currency=currency, quantity=quantity)
            products_to_create.append(product)
        Product.objects.bulk_create(products_to_create)
        print("Product created")