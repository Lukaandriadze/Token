from django.shortcuts import render

from rest_framework.generics import GenericAPIView
from rest_framework.mixins import ListModelMixin, RetrieveModelMixin, CreateModelMixin
from categories.models import Category, CategoryImage
from categories.serializers import CategorySerializer, CategoryDetailSerializer, CategoryImageSerializer
from rest_framework.viewsets import ModelViewSet

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter
class CategoryListView(ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    filter_backends = [DjangoFilterBackend,SearchFilter]
    search_fields = ['name']
    

class CategoryDetailView(ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategoryDetailSerializer



class CategoryImageViewSet(ModelViewSet):
    queryset = CategoryImage.objects.all()
    serializer_class = CategoryImageSerializer
    http_method_names = ['get','post']

    def get_queryset(self):
        category_id = self.kwargs['category_id']        
        return self.queryset.filter(category=category_id)
