from django.urls import path
from categories.views import CategoryListView, CategoryDetailView, CategoryImageViewSet

urlpatterns = [
    path('categories/', CategoryListView.as_view({'get': 'list', 'post': 'create'}), name='category-list'),
    path('categories/<int:pk>/', CategoryDetailView.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update'}), name='category-detail'),
    path('categories/<int:category_id>/images/', CategoryImageViewSet.as_view({'get': 'list', 'post': 'create'}), name='category-images'),
]
